/* Mandatory include */
#include "sdk_mts.h"

/* Test includes */
#include <stdio.h>
#include <string.h>
#include <stdint.h>

/* Auto called by framework BEFORE EACH test */
TEST_SETUP()
{

}

TEST_TEARDOWN()
{
    
}

/* Test for SystemInit */
TEST_UNIT(SystemInit)
{
    TEST_DESCRIPTION("Dummy test");
    TEST_LOG("Dummy test");
    
    TEST_PASS();
}